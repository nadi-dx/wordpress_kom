<?php
$dataset = file_get_contents('http://192.168.1.102/dataset');
echo $dataset;
 ?>
