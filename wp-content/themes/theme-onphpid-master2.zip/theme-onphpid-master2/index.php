<?php
get_header();?>

<!-- Page Header -->
<!-- Set your background image for this header on the line below. -->
<?php
get_header('home'); ?>

<?php
get_footer();
