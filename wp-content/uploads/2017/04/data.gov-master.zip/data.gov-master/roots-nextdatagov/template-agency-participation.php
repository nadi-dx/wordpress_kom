<?php
/*
Template Name: Agency Participation
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'agency-participation'); ?>