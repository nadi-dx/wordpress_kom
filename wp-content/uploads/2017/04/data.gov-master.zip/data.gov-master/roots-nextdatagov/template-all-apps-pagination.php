<?php
/*
Template Name:All Applications Pagination
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'all-apps-pagination'); ?>
