<?php
/*
Template Name:Category Applications
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'category-apps'); ?>
