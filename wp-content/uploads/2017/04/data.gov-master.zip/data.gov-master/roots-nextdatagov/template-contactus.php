<?php
/*
Template Name: Contact US
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'contactus'); ?>