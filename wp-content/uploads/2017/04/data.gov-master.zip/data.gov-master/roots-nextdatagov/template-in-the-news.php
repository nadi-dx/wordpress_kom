<?php
/*
Template Name:In The News
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'in-the-news'); ?>