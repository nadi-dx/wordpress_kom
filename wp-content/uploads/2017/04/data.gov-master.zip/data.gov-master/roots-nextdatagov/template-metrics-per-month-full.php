<?php
/*
Template Name: Datasets Published per Month - Full
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'metrics-per-month-full'); ?>
