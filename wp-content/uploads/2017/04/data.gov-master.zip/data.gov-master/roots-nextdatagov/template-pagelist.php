<?php
/*
Template Name: Pagelist
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'pagelist'); ?>