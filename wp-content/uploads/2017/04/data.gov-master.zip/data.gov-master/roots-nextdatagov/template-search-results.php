<?php
/*
Template Name: USA Search
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'search-results'); ?>
