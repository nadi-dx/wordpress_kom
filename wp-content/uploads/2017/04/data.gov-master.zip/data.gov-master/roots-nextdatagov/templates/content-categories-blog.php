<?php get_template_part( 'templates/category', 'subnav' ); ?>
<?php get_template_part( 'templates/category', 'posts' ); ?>